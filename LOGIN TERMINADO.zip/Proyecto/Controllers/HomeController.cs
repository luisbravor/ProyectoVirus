﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Escuela.Models;
using Escuela.Model;
using System.Web;
using Escuela.library;

namespace Escuela.Controllers
{
   
    public class HomeController : Controller
    {
         public int p,c;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
           _logger = logger;
        }

        public IActionResult Index( string message="")
        {
            ViewBag.Messge = message;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult login(string message="") { 
                        ViewBag.Messge = message;

            return View();
        }
        [HttpPost]
        public IActionResult login(string Nomina ,string contraseña)
        {
            if (!string.IsNullOrEmpty(Nomina) && !string.IsNullOrEmpty(contraseña)) { 
                int nomina = Int32.Parse(Nomina);
                int nominac = Int32.Parse(Nomina);
                //contraseña = Seguridad.Encriptar(contraseña);
                EscuelaFULLContext db = new EscuelaFULLContext();
                var user = db.Profesor.FirstOrDefault(p => p.NominaProfesor == nomina && p.ContraseñaProfesor == contraseña);
                var userc = db.Coordinador.FirstOrDefault(p => p.NominaCoordinador == nominac && p.ContraseñaCoordinador == contraseña);

                if(user!=null){p = user.NominaProfesor;}
                if(userc!=null){c = userc.NominaCoordinador;}
                  

                    if (user!=null  && p >= 1000 && p < 5000 ){ 
                        return RedirectToAction("lista_profesores", "Profesor");
                    }
                    else if(userc!=null && c >= 5000)
                    {
                        return RedirectToAction("lista_profesoresc", "Coordinador");
                    }
                    else { 
                    //hay error con los datos del usuario 
                    return login("No encotramos los datos");
                    }
            }else 
            {
                return login("llena los campos para iniciar sesion");
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
