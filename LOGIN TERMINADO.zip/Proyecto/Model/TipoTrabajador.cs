﻿using System;
using System.Collections.Generic;

namespace Escuela.Model
{
    public partial class TipoTrabajador
    {
        public int IdTipoTrabajador { get; set; }
        public string NombreTipoTrabajador { get; set; }
    }
}
